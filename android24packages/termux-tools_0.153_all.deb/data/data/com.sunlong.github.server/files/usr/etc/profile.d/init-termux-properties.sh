if [ ! -f /data/data/com.sunlong.github.server/files/home/.config/termux/termux.properties ] && [ ! -e /data/data/com.sunlong.github.server/files/home/.termux/termux.properties ]; then
mkdir -p /data/data/com.sunlong.github.server/files/home/.termux
cp /data/data/com.sunlong.github.server/files/usr/share/examples/termux/termux.properties /data/data/com.sunlong.github.server/files/home/.termux/
fi
