##
## This script is sourced by /data/data/com.sunlong.github.server/files/usr/bin/login before executing shell.
##
